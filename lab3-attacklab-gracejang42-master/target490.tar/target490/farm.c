/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_385()
{
    return 3347662957U;
}

unsigned getval_303()
{
    return 3281016988U;
}

void setval_347(unsigned *p)
{
    *p = 2420648213U;
}

void setval_395(unsigned *p)
{
    *p = 2488831196U;
}

unsigned addval_123(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_291(unsigned x)
{
    return x + 3267856712U;
}

void setval_346(unsigned *p)
{
    *p = 3284633672U;
}

unsigned addval_433(unsigned x)
{
    return x + 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_122()
{
    return 3252717896U;
}

void setval_365(unsigned *p)
{
    *p = 3767076914U;
}

unsigned addval_276(unsigned x)
{
    return x + 3531129481U;
}

unsigned getval_442()
{
    return 3676881545U;
}

void setval_134(unsigned *p)
{
    *p = 3286272328U;
}

unsigned addval_452(unsigned x)
{
    return x + 3677933195U;
}

void setval_140(unsigned *p)
{
    *p = 3281179017U;
}

unsigned getval_219()
{
    return 3375415945U;
}

unsigned getval_399()
{
    return 3353381192U;
}

unsigned addval_268(unsigned x)
{
    return x + 3464618041U;
}

unsigned addval_338(unsigned x)
{
    return x + 3383021193U;
}

unsigned addval_251(unsigned x)
{
    return x + 3285060084U;
}

unsigned addval_496(unsigned x)
{
    return x + 3281044107U;
}

unsigned getval_183()
{
    return 3281044105U;
}

void setval_299(unsigned *p)
{
    *p = 3281044105U;
}

void setval_336(unsigned *p)
{
    *p = 3531919755U;
}

unsigned addval_321(unsigned x)
{
    return x + 3375940225U;
}

unsigned getval_160()
{
    return 3534016905U;
}

void setval_455(unsigned *p)
{
    *p = 2445445464U;
}

unsigned getval_110()
{
    return 3372797579U;
}

void setval_437(unsigned *p)
{
    *p = 3269495112U;
}

void setval_444(unsigned *p)
{
    *p = 3676885385U;
}

unsigned getval_290()
{
    return 3531919753U;
}

unsigned getval_443()
{
    return 3375943305U;
}

void setval_126(unsigned *p)
{
    *p = 3286272328U;
}

void setval_340(unsigned *p)
{
    *p = 3286276424U;
}

void setval_289(unsigned *p)
{
    *p = 3375943304U;
}

void setval_468(unsigned *p)
{
    *p = 3465146565U;
}

unsigned getval_482()
{
    return 3286272329U;
}

unsigned getval_174()
{
    return 3378565513U;
}

void setval_440(unsigned *p)
{
    *p = 3285305673U;
}

unsigned getval_323()
{
    return 3682914697U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
